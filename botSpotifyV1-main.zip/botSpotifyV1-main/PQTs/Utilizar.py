# -*- coding: utf-8 -*-


  #-----------------#
 #---> MongoDB <---#
#-----------------#

UrlDB = "mongodb+srv://silklips:!Fps91507856@mycrypta.ugxec.mongodb.net/?retryWrites=true&w=majority"

#--> DB
accountsDB = "accounts"

#--> colecciones

""" 
acc_user_info_singup
accountmanager
neverinstall
neverinstall_loging_log
tinytask
"""


  #----------------------#
 #---> Neverinstall <---#
#----------------------#

urlNeverInstall='https://neverinstall.com/signin'

  #-----------------#
 #---> Spotify <---#
#-----------------#

urlSpotify = 'https://www.spotify.com/'

urlSpotifyLogin = 'https://accounts.spotify.com/'

passwordSpotify = "!asdf2021"
